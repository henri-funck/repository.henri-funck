# Librespot Connect for Kodi

Librespot Connect is an addon for Kodi that lets you play Spotify through Kodi.
It requires Kodi, Librespot and FFmpeg to run, and a Spotify Premium account to use.

Librespot Connect is a derivative of Librespot for LibreELEC that does not require a specific operating system or a PulseAudio server.
However, it is up to the user to install recent version of Librespot and FFmpeg on his system.

Librespot Connect can be installed alongside Librespot for LibreELEC.
